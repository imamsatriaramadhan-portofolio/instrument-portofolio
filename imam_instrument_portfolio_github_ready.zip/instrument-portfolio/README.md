# Instrument Portfolio

Professional instrumentation and control engineering portfolio for Imam Satria Ramadhan.

## How to add new cases

Open `data.js`, then add a new object inside the `cases` array:

```js
{
  id: '046',
  equipment: 'TAG-NAME',
  category: 'Flowmeter',
  title: 'Short Case Title',
  issue: 'Problem statement.',
  actions: ['Action 1', 'Action 2', 'Action 3'],
  result: 'Final result or recommendation.'
}
```

## GitHub Pages

Repository settings:

1. Go to Settings
2. Pages
3. Source: Deploy from a branch
4. Branch: main
5. Folder: /root
6. Save

Expected URL:

`https://imamsatriaramadhan-portofolio.github.io/instrument-portfolio/`
